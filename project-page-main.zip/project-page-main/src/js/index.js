// GESTION DES BOUTONS "ACHETER"
function changeColor() {
  if (this.classList.contains("clicked")) {
    this.classList.remove("clicked");
    this.classList.remove("no-model");
  } else {
    this.classList.add("clicked");
    const parent = this.closest('.card');
    const model = parent?.querySelector('.model');
    if (model) {
      alert(`Vous avez cliqué sur ${model.textContent.trim()}`);
    } else {
      this.classList.add("no-model");
      alert("Modèle sans nom.... :((");
    }
  }
}

document.querySelectorAll('.toggle').forEach(button => {
  button.addEventListener('click', changeColor);
});

// NAVBAR QUI SLIDE EN HAUT AU SCROLL
let lastScrollTop = 0;
const header = document.querySelector("header");
const nav = document.querySelector("nav");
const navItems = document.querySelector(".nav-items");
const logo = document.querySelector(".logo");

function hideNavbar() {
  header.classList.add("nav-hidden");
  navItems.classList.add("nav-items-hidden");
}

function showNavbar() {
  header.classList.remove("nav-hidden");
  nav.classList.remove("nav-hidden");
  navItems.classList.remove("nav-items-hidden");
}

window.addEventListener("scroll", () => {
  const scrollTop = window.scrollY;
  if (scrollTop > lastScrollTop && scrollTop > 100) {
    hideNavbar();
  } else {
    showNavbar();
  }
  lastScrollTop = scrollTop;
});

document.querySelector(".hover-zone").addEventListener("mouseenter", showNavbar);

logo.addEventListener("click", e => {
  e.preventDefault();
  window.scrollTo({ top: 0, behavior: "smooth" });
});

document.addEventListener("DOMContentLoaded", () => {
  const charts = [
    {
      id: 'chart-4060-6600',
      labels: ['Mémoire (Go)', 'CUDA/Stream Cores', 'Fréquence Boost (GHz)', 'Conso (W)', 'FPS 1080p'],
      datasets: [
        { label: 'RTX 4060', data: [8, 3072, 2.4, 115, 100], backgroundColor: 'rgba(54, 162, 235, 0.6)' },
        { label: 'RX 6600', data: [8, 1792, 2.4, 132, 90], backgroundColor: 'rgba(255, 99, 132, 0.6)' }
      ]
    },
    {
      id: 'chart-4070-6750xt',
      labels: ['Mémoire (Go)', 'Cores', 'Boost (GHz)', 'Conso (W)', 'FPS 1080p'],
      datasets: [
        { label: 'RTX 4070', data: [12, 5888, 2.5, 200, 120], backgroundColor: 'rgba(54, 162, 235, 0.6)' },
        { label: 'RX 6750 XT', data: [12, 2560, 2.6, 250, 110], backgroundColor: 'rgba(255, 99, 132, 0.6)' }
      ]
    },
    {
      id: 'chart-4080-7900xt',
      labels: ['Mémoire (Go)', 'Cores', 'Boost (GHz)', 'Conso (W)', 'FPS 1440p'],
      datasets: [
        { label: 'RTX 4080', data: [16, 9728, 2.5, 320, 160], backgroundColor: 'rgba(54, 162, 235, 0.6)' },
        { label: 'RX 7900 XT', data: [20, 5376, 2.4, 300, 145], backgroundColor: 'rgba(255, 99, 132, 0.6)' }
      ]
    },
    {
      id: 'chart-4080s-7900xtx',
      labels: ['Mémoire (Go)', 'Cores', 'Boost (GHz)', 'Conso (W)', 'FPS 4K'],
      datasets: [
        { label: 'RTX 4080 Super', data: [16, 10240, 2.55, 340, 145], backgroundColor: 'rgba(54, 162, 235, 0.6)' },
        { label: 'RX 7900 XTX', data: [24, 6144, 2.5, 355, 140], backgroundColor: 'rgba(255, 99, 132, 0.6)' }
      ]
    }
  ];

  const options = {
    responsive: true,
    animation: {
      duration: 1000,
      easing: 'easeOutBounce'
    },
    scales: {
      y: {
        beginAtZero: true
      }
    }
  };

  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const canvas = entry.target;
        const chartConfig = charts.find(c => c.id === canvas.id);
        if (chartConfig) {
          new Chart(canvas.getContext('2d'), {
            type: 'bar',
            data: {
              labels: chartConfig.labels,
              datasets: chartConfig.datasets
            },
            options
          });
          obs.unobserve(canvas);
        }
      }
    });
  }, { threshold: 0.3 });

  charts.forEach(c => {
    const canvas = document.getElementById(c.id);
    if (canvas) observer.observe(canvas);
  });
});
